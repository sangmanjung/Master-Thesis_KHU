function Z = correlation_based_distance(X,Y)

if length(size(X)) == 3
    for i = 1:size(X,3)
       Z(:,:,i) = sqrt(1-abs(corr(X(:,:,i),Y(:,:,i))));
       Z(:,:,i) = Z(:,:,i) - diag(diag(Z(:,:,i)));
    end
elseif length(size(X)) < 3
    Z = sqrt(1-abs(corr(X,Y))); 
    Z = Z - diag(diag(Z));
end
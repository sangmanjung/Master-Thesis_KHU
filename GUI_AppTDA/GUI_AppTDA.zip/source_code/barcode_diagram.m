function [intervals,betti_numbers] = barcode_diagram(choice,distance,max_dimension,max_filtration,subname)
import edu.stanford.math.plex4.*;

options.max_filtration_value = max_filtration;
options.max_dimension = max_dimension - 1;
if nargin == 5
    options.filename = subname; % title
end
point_cloud = metric.impl.ExplicitMetricSpace(distance);
stream = api.Plex4.createVietorisRipsStream(point_cloud,max_dimension,max_filtration,1000);
persistence = api.Plex4.getModularSimplicialAlgorithm(max_dimension,2);
intervals = persistence.computeIntervals(stream);

infinite_barcodes = intervals.getInfiniteIntervals();

% betti_numbers_array = infinite_barcodes.getBettiSequence() % as an array
% as a list with entries of the form k : Betti_{k}

betti_numbers = infinite_barcodes.getBettiNumbers();
intervals = persistence.computeAnnotatedIntervals(stream);
if choice == 1
    plot_barcodes(intervals, options);
elseif choice == 2
    persistence_diagram(intervals,0,max_dimension-1,subname)
elseif choice == 3
    plot_barcodes(intervals, options);
    persistence_diagram(intervals,0,max_dimension-1,subname)
end

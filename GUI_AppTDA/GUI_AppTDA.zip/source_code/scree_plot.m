function [seqk,WSS] = scree_plot(data,k,rep,title_val)

if nargin < 2
    k = 15;
    rep = 10;
elseif nargin == 2
    rep = 10;
end

seqk = (1:k)';
[n,p,m]=opt_factor_matsize(data);

if length(size(data)) == 3
    for k_iter = 1:k
        sumd = [];
        for i = 1:size(data,3)
            [~,~,sumd(:,i)] = kmeans(data(:,:,i),k_iter,'Replicates',rep);
        end
        if k_iter == 1
            WSS(1,:) = sumd.^2;
        else
            WSS(k_iter,:) = (sum(sumd).^2);
        end
    end
    figure('Name','Scree plot for k-means clustering');
    for pl_iter = 1:m
        subplot(n,p,pl_iter)
        plot(seqk,WSS(:,pl_iter),'-*b');
        xlabel('K'); ylabel('WSS');
        ax=gca; ax.XGrid='on';
        if nargin == 4
            title(sprintf('%s %d',title_val,pl_iter));
            tt = get(gca,'title');
            tt.FontWeight = 'bold';
        else
            title(sprintf('%s %d','no.',pl_iter));
            tt = get(gca,'title');
            tt.FontWeight = 'bold';
        end
    end
elseif length(size(data)) < 3
    for k_iter = 1:k
        [~,~,sumd] = kmeans(data,k_iter,'Replicates',rep);
        WSS(k_iter) = sum(sumd).^2;
    end
    WSS = WSS';
    figure('Name','Scree plot for k-means clustering');
    plot(seqk,WSS,'-*b');
    xlabel('K'); ylabel('WSS');
    ax=gca; ax.XGrid='on';
    if nargin == 4
        title(sprintf('%s',title_val));
        tt = get(gca,'title');
        tt.FontWeight = 'bold';
    else
        title(sprintf('%s','Scree plot for k-means'));
        tt = get(gca,'title');
        tt.FontWeight = 'bold';
    end
end


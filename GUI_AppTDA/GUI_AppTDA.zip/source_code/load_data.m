function X = load_data(filename)

[~,sheets] = xlsfinfo(filename);
opts = detectImportOptions(filename);

if length(cellstr(sheets)) == 1
    X = readmatrix(filename);
else
    for i=1:length(sheets)
        opts.Sheet = cell2mat(sheets(i));
        X(:,:,i) = readmatrix(filename,opts);
    end
end


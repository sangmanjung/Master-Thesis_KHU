function max_dist = dendroplot(MST,color_palette)

figure('Name','Dendrogram')
if size(MST,3) > 1
    [n,p,m]=opt_factor_matsize(MST);
    for i = 1:size(MST,3)
        subplot(n,p,i);
        if nargin > 1
            max_dist(i) = dendrograms(MST(:,:,i),color_palette);
        else
            max_dist(i) = dendrograms(MST(:,:,i));
        end
        ax=gca; ax.XGrid='on';
        xlabel('Filtration value');
        ylabel('Index of nodes');
        ax.Color = 'k';
        ax.GridColor = [1 1 1];
        ax.GridLineStyle = '--';
        ax.GridAlpha = 0.5;
        title(['no.',num2str(i)]);
        tt = get(gca,'title');
        tt.FontWeight = 'bold';
    end
else
    if nargin > 1
        max_dist = dendrograms(MST,color_palette);
    else
        max_dist = dendrograms(MST);
    end
    ax=gca; ax.XGrid='on';
    xlabel('Filtration value');
    ylabel('Index of nodes');
    ax.Color = 'k';
    ax.GridColor = [1 1 1];
    ax.GridLineStyle = '--';
    ax.GridAlpha = 0.5;
    title('Dendrogram');
    tt = get(gca,'title');
    tt.FontWeight = 'bold';
end

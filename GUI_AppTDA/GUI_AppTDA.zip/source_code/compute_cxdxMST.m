function [cx,dx,MST] = compute_cxdxMST(X,Y)

if nargin == 2
    cx = correlation_based_distance(X,Y);
else
    cx = correlation_based_distance(X,X);
end

if length(size(X)) == 3
    for i = 1:size(X,3)
        [dx(:,:,i),MST(:,:,i)] = single_linkage_matrix(cx(:,:,i));
    end
else
    [dx,MST] = single_linkage_matrix(cx);
end
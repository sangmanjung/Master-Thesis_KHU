function GH = Gromov_Hausdorff_distance(X,dx)

if length(size(X)) == 3
    for i = 1:size(X,3)
        for j = 1:size(X,3)
            pair = correspondence(X(:,:,i),X(:,:,j));
            GH(i,j) = max(max(abs(dx(pair(:,1),pair(:,1),i)-dx(pair(:,2),pair(:,2),j))));
        end
    end
end

function bc = barcode_curve(MST,max_filtration,color_palette)

if nargin < 2
    max_filtration = max(max(MST(:,3,:)))+max(max(MST(:,3,:)))/size(MST,1);
    color_palette = @parula;
elseif nargin == 2
    color_palette = @parula;
end

figure('Name','The curve of the barcode')
if length(size(MST)) == 3
    subplot(1,2,1)
    for i = 1:size(MST,3)
        A(:,i) = sort([max_filtration; MST(:,3,i)],'descend');
        bc = plot([0; MST(:,3,i); max_filtration],...
            [size(MST,1)+1 sort(1:size(MST,1),'descend') 1],'LineWidth',2);
        maps = colormap(color_palette(size(MST,3)));
        bc.Color = maps(i,:);
        hold on;
    end
    xlim([0 max_filtration]);
    ylim([0 size(MST,1)+2]);
    xlabel('filtration value');
    ylabel('the number of connected components');
    title('The curves of Betti-0 barcodes in 2D');
    
    subplot(1,2,2)
    bar3h(A);
    zlim([0 size(MST(:,3,1),1)+2]);
    ylim([0 max_filtration]);
    ylabel('filtration value')
    h = get(gca,'ylabel');
    set(h,'Rotation',-33)
     title('The curves of Betti-0 barcodes in 3D')
else
    bc = plot([0; MST(:,3); max_filtration],...
        [size(MST,1)+1 sort(1:size(MST,1),'descend') 1],'LineWidth',2);
    xlim([0 max_filtration]);
    xlabel('filtration value');
    ylabel('the number of connected components');
    title('The curve of Betti-0 barcode plot')
end
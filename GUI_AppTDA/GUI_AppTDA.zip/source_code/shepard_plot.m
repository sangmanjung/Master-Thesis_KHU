function [Y,r] = shepard_plot(distances,dimension,criterion)

if size(distances,3) == 1
    [Y,~,disparities_tmp] = mdscale(distances,dimension,'Criterion',criterion);
    Output_d = pdist(Y);
    r = corrcoef(squareform(distances),Output_d);
    endpts = max(max(distances));
    dissimilarities = squareform(distances);
    disparities = squareform(disparities_tmp);
    if criterion(1) == 's'
        if criterion(2) == 'a'
            figure('Name',sprintf('%dD Shepard plot - %s',dimension,criterion))
            subplot(1,1,1)
            sgtitle('Shepard Plot for Multidimensional Scaling')
            plot(squareform(distances),Output_d,'bo',[0 endpts],[0 endpts],'r--');
            title(sprintf('Dimension = %d     Criterion = %s     Pearson = %1.4f',...
                dimension,criterion,r(2)))
            xlabel('Input distances')
            ylabel('Output distances')
        elseif criterion(4) == 'a'
            figure('Name',sprintf('%dD Shepard plot - %s',dimension,criterion))
            subplot(1,1,1)
            sgtitle('Shepard Plot for Multidimensional Scaling')
            plot(squareform(distances),Output_d,'bo',[0 endpts],[0 endpts],'r--');
            title(sprintf('Dimension = %d     Criterion = %s     Pearson = %1.4f',...
                dimension,criterion,r(2)))
            xlabel('Input distances')
            ylabel('Output distances')
        else
            [~,ord] = sortrows([disparities(:) dissimilarities(:)]);
            figure('Name',sprintf('%dD Shepard plot - %s',dimension,criterion))
            subplot(1,1,1)
            sgtitle('Shepard Plot for Multidimensional Scaling')
            plot(squareform(distances),Output_d,'bo',dissimilarities(ord),disparities(ord),'r.-');
            title(sprintf('Dimension = %d     Criterion = %s     Pearson = %1.4f',...
                dimension,criterion,r(2)))
            xlabel('Input distances')
            ylabel('Output distances')
        end
    else
        figure('Name',sprintf('%dD Shepard plot - %s',dimension,criterion))
        subplot(1,1,1)
        sgtitle('Shepard Plot for Multidimensional Scaling')
        plot(squareform(distances),Output_d,'bo',[0 endpts],[0 endpts],'r--');
        title(sprintf('Dimension = %d     Criterion = %s     Pearson = %1.4f',...
            dimension,criterion,r(2)))
        xlabel('Input distances')
        ylabel('Output distances')
    end
    
elseif size(distances,3) > 1
    [n,p,m] = opt_factor_matsize(distances);
    endpts = zeros(1,m);
    Output_d{:} = [];
    Y = zeros(size(distances,2),dimension);
    r = zeros(2,2,m);
    
    for i = 1:m
        [Y_tmp,~,disparities_tmp(:,:,i)] = mdscale(distances(:,:,i),dimension,'Criterion',criterion);
        Output_d(i) = {pdist(Y_tmp)};
        Y(:,:,i) = Y_tmp;
        r(:,:,i) = corrcoef(squareform(distances(:,:,i)),cell2mat(Output_d(i)));
        endpts(i) = max(max(distances(:,:,i)));
        dissimilarities(i,:) = squareform(distances(:,:,i));
        disparities(i,:) = squareform(disparities_tmp(:,:,i));
    end
    
    figure('Name',sprintf('%dD Shepard plot - %s',dimension,criterion))
    if criterion(1) == 's'
        if criterion(2) == 'a'
            for i = 1:m
                subplot(n,p,i)
                sgtitle(sprintf('Shepard Plot for Multidimensional Scaling (%dD)',dimension))
                plot(squareform(distances(:,:,i)),cell2mat(Output_d(i)),'bo',...
                    [0 endpts(i)],[0 endpts(i)],'r--');
                title(sprintf('[%d] %s : %1.4f',i,criterion,r(1,2,i)))
                xlabel('Input distances')
                ylabel('Output distances')
            end
        elseif criterion(4) == 'a'
            for i = 1:m
                subplot(n,p,i)
                sgtitle(sprintf('Shepard Plot for Multidimensional Scaling (%dD)',dimension))
                plot(squareform(distances(:,:,i)),cell2mat(Output_d(i)),'bo',...
                    [0 endpts(i)],[0 endpts(i)],'r--');
                title(sprintf('[%d] %s : %1.4f',i,criterion,r(1,2,i)))
                xlabel('Input distances')
                ylabel('Output distances')
            end
        else
            for i = 1:m
                [~,ord] = sortrows([disparities(i,:)' dissimilarities(i,:)']);
                subplot(n,p,i)
                sgtitle(sprintf('Shepard Plot for Multidimensional Scaling (%dD)',dimension))
                plot(squareform(distances(:,:,i)),cell2mat(Output_d(i)),'bo',...
                    dissimilarities(i,ord),disparities(i,ord),'r.-');
                title(sprintf('[%d] %s : %1.4f',i,criterion,r(1,2,i)))
                xlabel('Input distances')
                ylabel('Output distances')
            end
        end
    else
        for i = 1:m
            subplot(n,p,i)
            sgtitle(sprintf('Shepard Plot for Multidimensional Scaling (%dD)',dimension))
            plot(squareform(distances(:,:,i)),cell2mat(Output_d(i)),'bo',...
                [0 endpts(i)],[0 endpts(i)],'r--');
            title(sprintf('[%d] %s : %1.4f',i,criterion,r(1,2,i)))
            xlabel('Input distances')
            ylabel('Output distances')
        end
    end
end

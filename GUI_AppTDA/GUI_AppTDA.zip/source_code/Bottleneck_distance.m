function BT = Bottleneck_distance(X,compdim,max_dimension,max_filtration)
import edu.stanford.math.plex4.*;

sub_num = size(X,3);
BT = zeros(sub_num,sub_num);
num_divisions = 1000;

for i=1:sub_num
    for j = 1:sub_num
        distancesX = X(:,:,i);
        point_cloudX = metric.impl.ExplicitMetricSpace(distancesX);
        streamX = api.Plex4.createVietorisRipsStream(point_cloudX, max_dimension,...
            max_filtration, num_divisions);
        persistenceX = api.Plex4.getModularSimplicialAlgorithm(max_dimension,2);
        intervalsX = persistenceX.computeIntervals(streamX);
        intervalsX = intervalsX.getIntervalsAtDimension(compdim);
        
        distancesY = X(:,:,j);
        point_cloudY = metric.impl.ExplicitMetricSpace(distancesY);
        streamY = api.Plex4.createVietorisRipsStream(point_cloudY, max_dimension,...
            max_filtration, num_divisions);
        persistenceY = api.Plex4.getModularSimplicialAlgorithm(max_dimension,2);
        intervalsY = persistenceY.computeIntervals(streamY);
        intervalsY = intervalsY.getIntervalsAtDimension(compdim);
        
        BT(i,j) = edu.stanford.math.plex4.bottleneck.BottleneckDistance.computeBottleneckDistance(intervalsX,intervalsY);
    end
end
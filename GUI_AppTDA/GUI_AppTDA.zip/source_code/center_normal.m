function Z = center_normal(X)

if size(X,3) == 1
    Z = zscore(X,0,1);
else
   for i = 1:size(X,3)
      Z(:,:,i) = zscore(X(:,:,i),0,1);
   end
end
    
function h = heatmaps(dist_matrix,color_palette)

figure('Name','Heatmap')
color_list = colormap(parula);

if nargin > 1
    color_list = colormap(color_palette);
    color_list = color_list(end:-1:1,:);
end

if size(dist_matrix,3) > 1
    [n,p,m]=opt_factor_matsize(dist_matrix);
    for i = 1:m
        subplot(n,p,i)
        imagesc(dist_matrix(:,:,i));colormap(color_list);colorbar;
        title(['no.',num2str(i)]);
        tt = get(gca,'title');
        tt.FontWeight = 'bold';
    end
else
    imagesc(dist_matrix);colormap(color_list);colorbar;
    title('Heatmap of the distance matrix');
    tt = get(gca,'title');
    tt.FontWeight = 'bold'; 
end
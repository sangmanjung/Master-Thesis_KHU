function [area,mean_area] = barcode_area(MST,max_filtration)

if nargin < 2
    max_filtration = max(max(MST(:,3,:)))+max(max(MST(:,3,:)))/size(MST,1);
end

A = zeros(size(MST,1),size(MST,2));
for i = 1:size(MST,3)
    A = A + MST(:,:,i);
end
A = A./size(MST,3);

area = zeros(size(MST,3),1);
for i = 1:size(MST,3)
    x = [0; MST(:,3,i); max_filtration];
    y = [size(MST,1)+1 sort(1:size(MST,1),'descend') 1];
    area(i,1) = trapz(x,y);
end
mean_area = mean(area);
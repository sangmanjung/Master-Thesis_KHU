function [Y,stress,c_ind] = mds_plot(distances,dim,criterion,k_num)

[n,p,m] = opt_factor_matsize(distances);

factors{:} = [];
for i = 1:size(distances,2)
    factors(i) = {i};
end

if m > 1
    if dim == 3
        Y = zeros(size(distances,2),dim,m);
        stress = zeros(m,1);
        for i = 1:m
            [Y(:,:,i),stress(i,:)] = mdscale(distances(:,:,i),dim,'Criterion',criterion);
            if nargin > 3
                if k_num <= 1
                    k_num = round(sqrt(size(distances,1)/2));
                end
                c_ind(:,i) = kmeans(Y(:,:,i),k_num);
            end
        end
        lmt = max(max(max(abs(Y))));
        lmt = lmt + lmt/5;
        if nargin > 3
            figure('Name',sprintf('Multidimensional scaling plot (%dD)',dim))
            for i = 1:m
                subplot(n,p,i)
                for k = 1:k_num
                    plot3(Y(c_ind(:,i)==k,1,i),Y(c_ind(:,i)==k,2,i),Y(c_ind(:,i)==k,3,i),'.','MarkerSize',15);
                    hold on;
                end
                text(Y(:,1,i),Y(:,2,i),Y(:,3,i),factors,'FontSize',10);
                axis([-lmt lmt -lmt lmt]);
                line([-lmt,lmt],[0 0],[0 0],'XLimInclude','off','Color',[.5 .5 .5]);
                line([0 0],[-lmt lmt],[0 0],'YLimInclude','off','Color',[.5 .5 .5]);
                line([0 0],[0 0],[-lmt lmt],'ZLimInclude','off','Color',[.5 .5 .5]);
                title(sprintf('%s %d','no.',i));
                tt = get(gca,'title');
                tt.FontWeight = 'bold';
                xlabel('dim 1');
                ylabel('dim 2');
                zlabel('dim 3');
                grid on
                hold off
            end
        else
            figure('Name',sprintf('Multidimensional scaling plot (%dD)',dim))
            for i = 1:m
                subplot(n,p,i)
                text(Y(:,1,i),Y(:,2,i),Y(:,3,i),factors,'FontSize',10);
                hold on
                axis([-lmt lmt -lmt lmt]);
                line([-lmt,lmt],[0 0],[0 0],'XLimInclude','off','Color',[.5 .5 .5]);
                line([0 0],[-lmt lmt],[0 0],'YLimInclude','off','Color',[.5 .5 .5]);
                line([0 0],[0 0],[-lmt lmt],'ZLimInclude','off','Color',[.5 .5 .5]);
                title(sprintf('%s %d','no.',i));
                tt = get(gca,'title');
                tt.FontWeight = 'bold';
                xlabel('dim 1');
                ylabel('dim 2');
                zlabel('dim 3');
                grid on
                hold off
            end
        end
    elseif dim < 3
        Y = zeros(size(distances,2),dim,m);
        stress = zeros(m,1);
        for i = 1:m
            [Y(:,:,i),stress(i,:)] = mdscale(distances(:,:,i),dim,'Criterion',criterion);
            if nargin > 3
                if k_num <= 1
                    k_num = round(sqrt(size(distances,1)/2));
                end
                c_ind(:,i) = kmeans(Y(:,:,i),k_num);
            end
        end
        lmt = max(max(max(abs(Y))));
        lmt = lmt + lmt/5;
        if nargin > 3
            figure('Name',sprintf('Multidimensional scaling plot (%dD)',dim))
            for i = 1:m
                subplot(n,p,i)
                for k = 1:k_num
                    plot(Y(c_ind(:,i)==k,1,i),Y(c_ind(:,i)==k,2,i),'.','MarkerSize',15);
                    hold on
                end
                text(Y(:,1,i),Y(:,2,i),factors,'FontSize',10);
                axis([-lmt lmt -lmt lmt]);
                line([-lmt,lmt],[0 0],'XLimInclude','off','Color',[.5 .5 .5]);
                line([0 0],[-lmt lmt],'YLimInclude','off','Color',[.5 .5 .5]);
                title(sprintf('%s %d','no.',i));
                tt = get(gca,'title');
                tt.FontWeight = 'bold';
                xlabel('dim 1');
                ylabel('dim 2');
                hold off
            end
        else
            figure('Name',sprintf('Multidimensional scaling plot (%dD)',dim))
            for i = 1:m
                subplot(n,p,i)
                text(Y(:,1,i),Y(:,2,i),factors,'FontSize',10);
                hold on
                axis([-lmt lmt -lmt lmt]);
                line([-lmt,lmt],[0 0],'XLimInclude','off','Color',[.5 .5 .5]);
                line([0 0],[-lmt lmt],'YLimInclude','off','Color',[.5 .5 .5]);
                title(sprintf('%s %d','no.',i));
                tt = get(gca,'title');
                tt.FontWeight = 'bold';
                xlabel('dim 1');
                ylabel('dim 2');
                hold off
            end
        end
    end
    if dim > 3
        Y = zeros(size(distances,2),dim,m);
        stress = zeros(m,1);
        for i = 1:m
            [Y(:,:,i),stress(i,:)] = mdscale(distances(:,:,i),dim,'Criterion',criterion);
        end
    end
elseif m == 1
    if dim == 3
        [Y,stress] = mdscale(distances,dim,'Criterion',criterion);
        lmt = max(max(abs(Y)));
        lmt = lmt + lmt/5;
        if nargin > 3
            if k_num <= 1
                k_num = round(sqrt(size(distances,1)/2));
            end
            c_ind = kmeans(Y,k_num);
            figure('Name',sprintf('Multidimensional scaling plot (%dD)',dim))
            for k = 1:k_num
                plot3(Y(c_ind==k,1),Y(c_ind==k,2),Y(c_ind==k,3),'.','MarkerSize',15);
                hold on;
            end
            text(Y(:,1),Y(:,2),Y(:,3),factors,'FontSize',10);
            axis([-lmt lmt -lmt lmt]);
            line([-lmt,lmt],[0 0],[0 0],'XLimInclude','off','Color',[.5 .5 .5]);
            line([0 0],[-lmt lmt],[0 0],'YLimInclude','off','Color',[.5 .5 .5]);
            line([0 0],[0 0],[-lmt lmt],'ZLimInclude','off','Color',[.5 .5 .5]);
            title('MDS plot and k-means clustering');
            tt = get(gca,'title');
            tt.FontWeight = 'bold';
            xlabel('dim 1');
            ylabel('dim 2');
            zlabel('dim 3');
            grid on
            hold off
        else
            figure('Name',sprintf('Multidimensional scaling plot (%dD)',dim))
            text(Y(:,1),Y(:,2),Y(:,3),factors,'FontSize',10);
            hold on
            axis([-lmt lmt -lmt lmt]);
            line([-lmt,lmt],[0 0],[0 0],'XLimInclude','off','Color',[.5 .5 .5]);
            line([0 0],[-lmt lmt],[0 0],'YLimInclude','off','Color',[.5 .5 .5]);
            line([0 0],[0 0],[-lmt lmt],'ZLimInclude','off','Color',[.5 .5 .5]);
            title(sprintf('%s %d','no.',i));
            tt = get(gca,'title');
            tt.FontWeight = 'bold';
            xlabel('dim 1');
            ylabel('dim 2');
            zlabel('dim 3');
            grid on
            hold off
        end
    elseif dim < 3
        [Y,stress] = mdscale(distances,dim,'Criterion',criterion);
        lmt = max(max(abs(Y)));
        lmt = lmt + lmt/5;
        if nargin > 3
            if k_num <= 1
                k_num = round(sqrt(size(distances,1)/2));
            end
            c_ind = kmeans(Y,k_num);
            figure('Name',sprintf('Multidimensional scaling plot (%dD)',dim))
            for k = 1:k_num
                plot(Y(c_ind==k,1),Y(c_ind==k,2),'.','MarkerSize',15);
                hold on;
            end
            text(Y(:,1),Y(:,2),factors,'FontSize',10);
            axis([-lmt lmt -lmt lmt]);
            line([-lmt,lmt],[0 0],'XLimInclude','off','Color',[.5 .5 .5]);
            line([0 0],[-lmt lmt],'YLimInclude','off','Color',[.5 .5 .5]);
            title('MDS plot and k-means clustering');
            tt = get(gca,'title');
            tt.FontWeight = 'bold';
            xlabel('dim 1');
            ylabel('dim 2');
            hold off
        else
            figure('Name',sprintf('Multidimensional scaling plot (%dD)',dim))
            text(Y(:,1),Y(:,2),factors,'FontSize',10);
            hold on
            axis([-lmt lmt -lmt lmt]);
            line([-lmt,lmt],[0 0],'XLimInclude','off','Color',[.5 .5 .5]);
            line([0 0],[-lmt lmt],'YLimInclude','off','Color',[.5 .5 .5]);
            title(sprintf('%s %d','no.',i));
            tt = get(gca,'title');
            tt.FontWeight = 'bold';
            xlabel('dim 1');
            ylabel('dim 2');
            hold off
        end
    end
    if dim > 3
        [Y,stress] = mdscale(distances,dim,'Criterion',criterion);
    end
end